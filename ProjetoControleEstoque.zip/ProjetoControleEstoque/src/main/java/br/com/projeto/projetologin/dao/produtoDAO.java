/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.projeto.projetologin.dao;

import br.com.projeto.projetologin.model.produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author autologon
 */
public class produtoDAO {
    private final Connection connection;
    
    public produtoDAO(Connection connection){
        this.connection = connection;
    }
    public void insert(produto produto) throws SQLException{

            String sql = "insert into tbl_produto (nome_produto, quantidade_produto, preco_produto, fornecedor_produto, tipo_produto) values (?,?,?,?,?);";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, produto.getNome());
            statement.setString(2, produto.getQuantidade());
            statement.setString(3,produto.getPreco());
            statement.setString(4,produto.getFornecedor());
            statement.setString(5,produto.getTipo());
            statement.execute();
    }
    public void update(produto produto) throws SQLException{
        String sql = "update tbl_produto set nome_produto = ?, quantidade_produto = ?, preco_produto = ?, fornecedor_produto = ?, tipo_produto = ?  where id_produto = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, produto.getNome());
        statement.setString(2, produto.getQuantidade());
        statement.setString(3, produto.getPreco());
        statement.setString(4, produto.getFornecedor());
        statement.setString(5, produto.getTipo());
        statement.setInt(6, produto.getId());
        statement.execute();
    }
    public void delete(produto produto) throws SQLException{
        String sql = "delete from tbl_produto where id_produto = ? ";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, produto.getId());
        statement.execute();
    }
}
