/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import br.com.projeto.projetologin.cadastroView;
import br.com.projeto.projetologin.dao.UsuarioDAO;
import br.com.projeto.projetologin.dao.conexao;
import br.com.projeto.projetologin.model.Usuario;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel
 */
public class cadastroController {
    private cadastroView view;

    public cadastroController(cadastroView view) {
        this.view = view;
    }
    
    public void cadastroUsuario(){
        
        String usuario = view.getjTextFieldUsuario().getText();
        String senha = view.getjPasswordFieldSenha().getText();
        Usuario usuarioenvie = new Usuario(usuario, senha);
        try {
            Connection conexao = new conexao().getConnection();
            UsuarioDAO usuarioDao = new UsuarioDAO(conexao);
            usuarioDao.insert(usuarioenvie);
            
            JOptionPane.showMessageDialog(null, "Usuario Salvo com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(cadastroView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
