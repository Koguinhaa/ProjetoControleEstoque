/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import br.com.projeto.projetologin.ViewLogin;
import br.com.projeto.projetologin.dao.UsuarioDAO;
import br.com.projeto.projetologin.dao.conexao;
import br.com.projeto.projetologin.menuView;
import br.com.projeto.projetologin.model.Usuario;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel
 */
public class loginController {
    private ViewLogin view;

    public loginController(ViewLogin view) {
        this.view = view;
    }

    public void autenticar() throws SQLException {
        String usuario = view.getTxtLogin().getText();
        String senha = view.getTxtSenha().getText();
        Usuario usuarioAutenticar = new Usuario(usuario, senha);
        
        Connection conexao = new conexao().getConnection();
        UsuarioDAO usuarioDao = new UsuarioDAO(conexao);
        boolean existe = usuarioDao.existeNoBancoPorUsuarioESenha(usuarioAutenticar);
        
        if(existe){
            menuView telaDeMenu = new menuView();
            telaDeMenu.setVisible(true);
        }else{
            JOptionPane.showMessageDialog(view, "Usuario ou senha invalidos");
        }
    }
    
}
