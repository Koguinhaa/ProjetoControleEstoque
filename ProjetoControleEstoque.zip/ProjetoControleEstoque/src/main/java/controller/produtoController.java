/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import br.com.projeto.projetologin.CadProduto;
import br.com.projeto.projetologin.dao.produtoDAO;
import br.com.projeto.projetologin.dao.conexao;
import br.com.projeto.projetologin.model.produto;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author autologon
 */
public class produtoController {
    private CadProduto view;
    
    public produtoController(CadProduto view){
        this.view = view;
    }
    public void cadastrarProduto(){
        String nome = view.getNome_produto().getText();
        String  quantidade = view.getQuantidadeProduto().getText();
        String  preco = view.getPrecoProduto().getText();
        String fornecedor = view.getFornecedorProduto().getText();
        String tipo = view.getTipoProduto().getText();
        produto produtoenvie = new produto(nome, quantidade, preco, fornecedor, tipo);
        try {
            Connection conexao = new conexao().getConnection();
            produtoDAO produtoDao = new produtoDAO(conexao);
            produtoDao.insert(produtoenvie);
            
            JOptionPane.showMessageDialog(null, "Produto Cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(CadProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
